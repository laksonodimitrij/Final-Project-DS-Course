from flask import Flask, render_template, request
import joblib
import pickle
import pandas as pd

app = Flask(__name__)

#halaman home
@app.route('/')
def home():
    return render_template('home.html')

#halaman about
@app.route('/about', methods=['GET', 'POST'])
def about():
    return render_template('about.html')

#halaman dataset
@app.route('/database', methods=['POST', 'GET'])
def dataset():
    return render_template('dataset.html')

# #halaman visualisasi
@app.route('/visualize', methods=['POST', 'GET'])
def visual():
    return render_template('plot.html')

# #halaman input prediksi
@app.route('/predict', methods = ['POST', 'GET'])
def predict():
    return render_template('predict.html')

# #halaman hasil prediksi
@app.route('/result', methods = ['POST', 'GET'])
def result():
    if request.method == 'POST':
        input = request.form

        df_predict = pd.DataFrame({
            'Experience':[input['Experience']],
            'Income':[input['Income']],
            'ZIP Code':[input['ZIP Code']],
            'Family':[input['Family']],
            'CCAvg':[input['CCAvg']],
            'Education':[input['Education']],
            'Mortgage':[input['Mortgage']],
            'Securities Account':[input['Securities Account']],
            'CD Account':[input['CD Account']],
            'Online':[input['Online']],
            'CreditCard':[input['CreditCard']],
        })


        prediksi = '{:.2%}'.format(model.predict_proba(df_predict)[0][1])
        print(prediksi)

        return render_template('result.html',
            data=input, pred=prediksi)

if __name__ == '__main__':

    filename = 'FM_Loan_Classification.sav'
    model = pickle.load(open(filename,'rb'))


    app.run(debug=True)